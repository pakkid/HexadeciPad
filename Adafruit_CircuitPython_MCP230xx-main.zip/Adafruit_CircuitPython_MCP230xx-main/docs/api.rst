
.. If you created a package, create one automodule per module in the package.

.. If your library file(s) are nested in a directory (e.g. /adafruit_foo/foo.py)
.. use this format as the module name: "adafruit_foo.foo"

.. automodule:: adafruit_mcp230xx.mcp23xxx
   :members:

.. automodule:: adafruit_mcp230xx.mcp230xx
   :members:

.. automodule:: adafruit_mcp230xx.mcp23008
   :members:

.. automodule:: adafruit_mcp230xx.mcp23016
   :members:

.. automodule:: adafruit_mcp230xx.mcp23017
   :members:

.. automodule:: adafruit_mcp230xx.mcp23sxx
   :members:

.. automodule:: adafruit_mcp230xx.mcp23s08
   :members:

.. automodule:: adafruit_mcp230xx.mcp23s17
   :members:

.. automodule:: adafruit_mcp230xx.digital_inout
   :members:
