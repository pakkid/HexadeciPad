# Atreus62

![Atreus62](https://assets.bigcartel.com/product_images/189335282/BIlqCtd.jpg?auto=format&fit=max&w=1200)

Atreus62 is a 60% column staggered keyboard pinky stagger 

kb.py is designed to work with the Teensy 4.1

Extensions enabled by default  
- [Layers](/docs/en/layers.md) Need more keys than switches? Use layers.
- [RGB](/docs/en/rgb.md) Light it up
- [Encoder](/docs/en/encoder.md) Twist control for all the things

